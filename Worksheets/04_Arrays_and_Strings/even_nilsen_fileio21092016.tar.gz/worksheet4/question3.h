#ifndef QUESTION3_H_2CLCM7JH
#define QUESTION3_H_2CLCM7JH

void print_array(int intArray[], int length);

#endif /* end of include guard: QUESTION3_H_2CLCM7JH */
