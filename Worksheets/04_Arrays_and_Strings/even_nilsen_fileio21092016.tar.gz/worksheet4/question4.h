#ifndef QUESTION4_H_HYZUZOMO
#define QUESTION4_H_HYZUZOMO

#include "question1.h"
#include "question2.h"
#include "question3.h"

int isEqual(char *str1, char *str2);
void string_to_integer(int intArray[], int args, char *argv[]);

#endif /* end of include guard: QUESTION4_H_HYZUZOMO */
