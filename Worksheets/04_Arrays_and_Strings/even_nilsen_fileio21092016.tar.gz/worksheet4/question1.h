#ifndef QUESTION1_H_SPCHFR1N
#define QUESTION1_H_SPCHFR1N

int sum(int intArray[], int length);
int max(int intArray[], int length);
void reverse(int intArray[], int end);


#endif /* end of include guard: QUESTION1_H_SPCHFR1N */
