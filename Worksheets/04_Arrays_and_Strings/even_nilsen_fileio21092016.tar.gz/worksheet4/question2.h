#ifndef QUESTION2_H_ZRP0SOOW
#define QUESTION2_H_ZRP0SOOW

void string_to_int(char *chArray[], int intArray[], int length);
void print_all(int intArray[], int length);

#endif /* end of include guard: QUESTION2_H_ZRP0SOOW */
