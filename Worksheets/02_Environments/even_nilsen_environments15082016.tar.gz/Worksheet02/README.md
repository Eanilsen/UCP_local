
Worksheet2 - Environments
Even A. Nilsen
15.08.2016

USAGE:
    make download   - compiles the program
    make all_stats  - compiles the program with the ALL_STATS directive
    make clean      - removes all the object files and the executable
    make help       - shows this message

