USAGE:
    make all    - compile all .c files
    make clean  - remove all executables
